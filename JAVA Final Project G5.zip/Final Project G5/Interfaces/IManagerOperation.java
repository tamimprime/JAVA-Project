package Interfaces;             //package used to group related classes.
import Classes.*;
public interface IManagerOperation
{
	/* All the methods are public abstract by default
    * As we see they have no body
    */
	
	
	void insertManager();
	Manager getManager();
}